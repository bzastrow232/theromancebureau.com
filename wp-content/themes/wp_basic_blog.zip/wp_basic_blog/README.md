# wpbasicbootstrapblog
This is a basic bootstrap blog for wordpress that is highly optimized for page speed.
This blog is fast, basic, and can be used as a personal blog, business blog or, an affiliate marketing site.
