<div class="card card-posts">
  <div class="card-body">

    <?php /** Output post title **/ ?>
    <?php /** If post is single **/ ?>
    <?php if(is_single()): ?>
      <h2 class="card-title">
        <?php the_title(); ?>
      </h2>

      <?php /** If post isn't single **/ ?>
      <?php else: ?>
        <h2 class="card-title">
          <a href = "<?php the_permalink(); ?>">
            <?php the_title(); ?>
          </a>
        </h2>

      <?php endif; ?>
    
      <span class="card-text card-text-posts-date"><?php the_time('F j, Y g:i a'); ?></span> 
      by
      <span class="card-text card-text-posts-author"><a href = "<?php echo get_author_posts_url(get_the_author_meta('ID')); ?>"><?php the_author(); ?></a></span>
      |
      <span class="card-text card-text-posts-comments"><a href = "<?php the_permalink(); ?>"><?php comments_number( 'No Comments', 'One Comment', '% Comments' ); ?>.</a></span></br></br>

      <?php /** Check if post has image **/ ?>
      <?php if(has_post_thumbnail()) : ?>
        <a href = "<?php the_permalink(); ?>">
          <div class ="post-thumb">
            <?php the_post_thumbnail(); ?>
          </div>
        </a>

        </br></br>

      <?php endif; ?>

      <?php /** Test exercpt or full post **/ ?>
      <p class="card-text card-text-posts">
        <?php if(is_single()): ?>
           <?php the_content(); ?>
        <?php else :  ?>
           <a class = "excerpt" href = "<?php the_permalink(); ?>">
            <?php the_excerpt(); ?>
           </a>
        <?php endif; ?>
      </p>
      <hr>

     <?php /** Post Category **/ ?>
      <?php
          // Get the ID of a given category
          $category_id = get_cat_ID( 'Category Name' );

          // Get the URL of this category
          $category_link = get_category_link( $category_id );
      ?>

      <span class="card-text card-text-posts-category">
      Category: <a href = "<?php echo esc_url( $category_link ); ?>">
          <?php echo get_the_category_list("Category"); ?>
        </a>
      </span>

      </br>

      <?php /** Post Tags **/ ?>
      <span class="card-text card-text-posts-tags">
       <?php the_tags( 'Tags: ', ', ', '<br />' ); ?> 
      </span>

      <?php /** Test comments **/ ?>
      <?php if(is_single()) : ?>
          <?php comments_template(); ?>
      <?php endif; ?>


  </div>
</div></br>