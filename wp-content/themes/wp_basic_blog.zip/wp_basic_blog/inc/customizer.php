<?php

//Register customized fields from backend
function bbb_customize_register($wp_customize){

	//Showcase section
	$wp_customize->add_section('showcase',array(
		'title' => __('Showcase','BasicBootstrapBlog'),
		'description' => sprintf(__("Options For Showcase",'basicbootstrapblog')),
		'priority' => 130
	));


	/** LOGO **/
	//Add new setting to edit page elemnts eg: text
	$wp_customize->add_setting('showcase_image',array(
		'default' => get_bloginfo('template_directory') .'/assets/img/showcase.PNG',
		'type' => 'theme_mod'
	));

	//Add control
	$wp_customize->add_control(new WP_Customize_Image_Control($wp_customize, 'showcase_image',array(
		'label' => __('Showcase Image', 'basicbootstrapblog'),
		'section' => 'showcase',
		'priority' => 1,
		'settings' => 'showcase_image'
	)));

	/** HEADER SOCIAL ICONS **/

	#Facebook URL
	$wp_customize->add_setting("facebook_url", array(
		'default' => _x('https://facebook.com','basicbootstrapblog'),
		'type' => 'theme_mod'
	));

	$wp_customize->add_control('facebook_url', array(
      'label'   => __('Facebook URL', 'basicbootstrapblog'),
      'section' => 'showcase',
      'priority'  => 2
    ));

	#Twitter URL
	$wp_customize->add_setting("twitter_url", array(
		'default' => _x('https://twitter.com','basicbootstrapblog'),
		'type' => 'theme_mod'
	));

	$wp_customize->add_control('twitter_url', array(
      'label'   => __('Twitter URL', 'basicbootstrapblog'),
      'section' => 'showcase',
      'priority'  => 3
    ));

    #Linkedin URL
	$wp_customize->add_setting("linkedin_url", array(
		'default' => _x('https://linkedin.com','basicbootstrapblog'),
		'type' => 'theme_mod'
	));

	$wp_customize->add_control('linkedin_url', array(
      'label'   => __('Linkedin URL', 'basicbootstrapblog'),
      'section' => 'showcase',
      'priority'  => 4
    ));

    #Pinterest URL
	$wp_customize->add_setting("pinterest_url", array(
		'default' => _x('https://pinterest.com','basicbootstrapblog'),
		'type' => 'theme_mod'
	));

	$wp_customize->add_control('pinterest_url', array(
      'label'   => __('Pinterest URL', 'basicbootstrapblog'),
      'section' => 'showcase',
      'priority'  => 5
    ));

    #Youtube URL
	$wp_customize->add_setting("youtube_url", array(
		'default' => _x('https://youtube.com','basicbootstrapblog'),
		'type' => 'theme_mod'
	));

	$wp_customize->add_control('youtube_url', array(
      'label'   => __('Youtube URL', 'basicbootstrapblog'),
      'section' => 'showcase',
      'priority'  => 6
    ));

    #RSS URL
	$wp_customize->add_setting("rss_url", array(
		'default' => _x('https://fetchrss.com','basicbootstrapblog'),
		'type' => 'theme_mod'
	));

	$wp_customize->add_control('rss_url', array(
      'label'   => __('Rss URL', 'basicbootstrapblog'),
      'section' => 'showcase',
      'priority'  => 7
    ));


    #Instgram URL
	$wp_customize->add_setting("instgram_url", array(
		'default' => _x('https://instgram.com','basicbootstrapblog'),
		'type' => 'theme_mod'
	));

	$wp_customize->add_control('instgram_url', array(
      'label'   => __('Instgram URL', 'basicbootstrapblog'),
      'section' => 'showcase',
      'priority'  => 8
    ));

    #Snapchat URL
	$wp_customize->add_setting("snapchat_url", array(
		'default' => _x('https://snapchat.com','basicbootstrapblog'),
		'type' => 'theme_mod'
	));

	$wp_customize->add_control('snapchat_url', array(
      'label'   => __('Snapchat URL', 'basicbootstrapblog'),
      'section' => 'showcase',
      'priority'  => 9
    ));


	#Google Plus URL
	$wp_customize->add_setting("googleplus_url", array(
		'default' => _x('https://plus.google.com','basicbootstrapblog'),
		'type' => 'theme_mod'
	));

	$wp_customize->add_control('googleplus_url', array(
      'label'   => __('GooglePlus URL', 'basicbootstrapblog'),
      'section' => 'showcase',
      'priority'  => 10
    ));



	/** TITLE **/
	// //Add new setting to edit page elemnts eg: text
	// $wp_customize->add_setting('showcase_heading',array(
	// 	'default' => _x('Sample Text', 'basicbootstrapblog'),
	// 	'type' => 'theme_mod'
	// ));

	// //Add control
	// $wp_customize->add_control('showcase_heading', array(
	// 	'label' => __('Heading','basicbootstrapblog'),
	// 	'section' => 'showcase',
	// 	'priority' => 1
	// ));


	/** FOOTER SOCIAL LINKS **/

	#Footer Facebook
	$wp_customize->add_setting("foot_facebook_url",array(
		"default" => _x("https://facebook.com","basicbootstrapblog"),
		"type" => "theme_mod"
	));

	$wp_customize->add_control("foot_facebook_url",array(
		"label" => __("Facebook Footer URL", "basicbootstrapblog"),
		"section" => "showcase",
		"priority" => 11
	));

	#Footer Twitter 
	$wp_customize->add_setting("foot_twitter_url",array(
		"default" => _x("https://twitter.com","basicbootstrapblog"),
		"type" => "theme_mod"
	));

	$wp_customize->add_control("foot_twitter_url",array(
		"label" => __("Twitter Footer URL", "basicbootstrapblog"),
		"section" => "showcase",
		"priority" => 12
	));

	#Footer Google Plus 
	$wp_customize->add_setting("foot_googleplus_url",array(
		"default" => _x("https://plus.google.com","basicbootstrapblog"),
		"type" => "theme_mod"
	));

	$wp_customize->add_control("foot_googleplus_url",array(
		"label" => __("Google Plus Footer URL", "basicbootstrapblog"),
		"section" => "showcase",
		"priority" => 13
	));

	#Footer Instagram
	$wp_customize->add_setting("foot_instagram_url",array(
		"default" => _x("https://instagram.com","basicbootstrapblog"),
		"type" => "theme_mod"
	));

	$wp_customize->add_control("foot_instagram_url",array(
		"label" => __("Instagram Footer URL", "basicbootstrapblog"),
		"section" => "showcase",
		"priority" => 14
	));

	#Footer Reddit 
	$wp_customize->add_setting("foot_reddit_url",array(
		"default" => _x("https://reddit.com","basicbootstrapblog"),
		"type" => "theme_mod"
	));

	$wp_customize->add_control("foot_reddit_url",array(
		"label" => __("Reddit Footer URL", "basicbootstrapblog"),
		"section" => "showcase",
		"priority" => 15
	));


	#Privacy Policy
	// $wp_customize->add_setting("privacy_policy", array(
	// 	"default" => _x("Privacy Policy", "basicbootstrapblog"),
	// 	"type" => "theme_mod"
	// ));

	// $wp_customize->add_control("privacy_policy", array(
	// 	"label" => __("Privacy Policy", "basicbootstrapblog"),
	// 	"section" => "showcase",
	// 	"priority" => 16
	// ));

}

//Initialize register hook to function
add_action('customize_register','bbb_customize_register');




?>