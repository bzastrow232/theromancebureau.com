          <div class = "col-md-4">

            <?php /** Primary Sidebar **/ ?>
            <div class = "col-md-12 sidebar">
               <?php if ( is_active_sidebar( 'sidebar' ) ) { ?>
                <div class = "card">
                  <div class = "card-body">
                    <ul id="sidebar">
                      <?php dynamic_sidebar( 'sidebar' ); ?>
                    </ul>
                  </div>
                </div>
              <?php } ?>
            </div></br>

            <?php /** Seconary Sidebar **/ ?>
            <div class = "col-md-12 sidebar">
               <?php if ( is_active_sidebar( 'secondary-sidebar' ) ) { ?>
                <div class = "card">
                  <div class = "card-body">
                    <ul id="sidebar">
                      <?php dynamic_sidebar( 'secondary-sidebar' ); ?>
                    </ul>
                  </div>
                </div>
              <?php } ?>
            </div></br>

            <?php /** Third Sidebar **/ ?>
            <div class = "col-md-12 sidebar">
               <?php if ( is_active_sidebar( 'Third-sidebar' ) ) { ?>
                <div class = "card">
                  <div class = "card-body">
                    <ul id="sidebar">
                      <?php dynamic_sidebar( 'Third-sidebar' ); ?>
                    </ul>
                  </div>
                </div>
              <?php } ?>
            </div></br>

            <?php /** Fourth Sidebar **/ ?>
            <div class = "col-md-12 sidebar">
               <?php if ( is_active_sidebar( 'Fourth-sidebar' ) ) { ?>
                <div class = "card">
                  <div class = "card-body">
                    <ul id="sidebar">
                      <?php dynamic_sidebar( 'Fourth-sidebar' ); ?>
                    </ul>
                  </div>
                </div>
              <?php } ?>
            </div></br>
          </div> <?php /** End Widgets **/ ?>
        </div> <?php /**  End row **/ ?>
      </div> <?php /** End container **/ ?>
    </main> <?php /** End Main **/ ?>

   <?php /** Start Footer **/ ?>
   <footer class="container-fluid">
    <p class = "footer-copyright">
      <span><a href="<?php echo get_theme_mod('foot_facebook_url','https://facebook.com'); ?>" target="_blank">Facebook</a></span>
      <span><a href="<?php echo get_theme_mod('foot_twitter_url','https://twitter.com'); ?>" target="_blank">Twitter</a></span>
      <span><a href="<?php echo get_theme_mod('foot_googleplus_url','https://plus.google.com'); ?>" target="_blank">Google+</a></span>
      <span><a href="<?php echo get_theme_mod('foot_instagram_url','https://instagram.com'); ?>" target="_blank">Instagram</a></span>
      <span><a href="<?php echo get_theme_mod('foot_reddit_url','https://reddit.com'); ?>" target="_blank">Reddit</a></span></br></br>
      Copyright © <?php echo date("Y"); ?> - <?php echo site_url(); ?></br></br>

      <span><a href="<?php echo the_permalink()."privacy-policy"; ?>">Privacy Policy</a></span> |
      <span><a href="<?php echo the_permalink()."disclaimer"; ?>">Disclaimer</a></span> |
      <span><a href="<?php echo the_permalink()."terms-and-conditions" ?>">Terms & Conditions</a></span>
    </p>
  </footer>

    <?php /** WP_Footer **/ ?>
    <?php wp_footer(); ?>
  </body>
</html>