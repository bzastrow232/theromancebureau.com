<!doctype html>
<html <?php language_attributes(); ?>>
  <head>
    <meta charset="<?php bloginfo('charset'); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="<?php bloginfo('description'); ?>">

    <title><?php bloginfo('name'); ?> |
    <?php is_front_page() ? bloginfo('description') : wp_title(); ?></title>

    <?php /**  WP HEADER **/ ?>
    <?php wp_head(); ?>

  </head>
  <body>
    
    <?php /** Header **/ ?>
    <header>
      <section class = "showcase">

        <nav class="navbar navbar-expand-md navbar-custom navbar-light" role="navigation" >

          <div class="container">

          <?php /** Brand and toggle get grouped for better mobile display **/ ?>
          <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-controls="bs-example-navbar-collapse-1" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
          </button>

          <?php /** Navbar Brand **/ ?>
          <a class="navbar-brand" href="<?php echo esc_url(home_url()); ?>">
            <img src = "<?php echo get_theme_mod('showcase_image', get_bloginfo('template_url').'/assets/img/showcase.PNG'); ?>">
          </a>

          <?php 
          wp_nav_menu( array(
                'theme_location'    => 'primary',
                'depth'             => 2,
                'container'         => 'div',
                'container_class'   => 'collapse navbar-collapse',
                'container_id'      => 'bs-example-navbar-collapse-1',
                'menu_class'        => 'nav navbar-nav',
                'fallback_cb'       => 'WP_Bootstrap_Navwalker::fallback',
                'walker'            => new WP_Bootstrap_Navwalker(),
            ) );
          ?>

      </div><?php /** End container **/ ?>
    </nav><?php /** End Navbar **/ ?>
    <nav class = "navbar navbar-nav secondary-nav">
      <ul class="navbar-nav seconary-nav-ul ml-auto">
        <li class="nav-item">
          <a class="nav-link" href="<?php echo get_theme_mod('facebook_url','https://facebook.com'); ?>" target="_blank"><i class="fab fa-facebook-f fa-2x"></i></a>
          <a class="nav-link" href="<?php echo get_theme_mod('twitter_url','https://twitter.com'); ?>" target="_blank"><i class="fab fa-twitter fa-2x"></i></a>
          <a class="nav-link" href="<?php echo get_theme_mod('linkedin_url','https://linkedin.com'); ?>" target="_blank"><i class="fab fa-linkedin-in fa-2x"></i></a>
          <a class="nav-link" href="<?php echo get_theme_mod('pinterest_url','https://pinterest.com'); ?>" target="_blank"><i class="fab fa-pinterest-p fa-2x"></i></a>
          <a class="nav-link" href="<?php echo get_theme_mod('youtube_url','https://youtube.com'); ?>" target="_blank"><i class="fab fa-youtube fa-2x"></i></a>
          <a class="nav-link" href="<?php echo get_theme_mod('rss_url','http://fetchrss.com/'); ?>" target="_blank"><i class="fas fa-rss fa-2x"></i></a>
          <a class="nav-link" href="<?php echo get_theme_mod('instagram_url','https://instagram.com'); ?>" target="_blank"><i class="fab fa-instagram fa-2x"></i></a>
          <a class="nav-link" href="<?php echo get_theme_mod('snapchat_url','https://snapchat.com'); ?>" target="_blank"><i class="fab fa-snapchat-ghost fa-2x"></i></a>
          <a class="nav-link" href="<?php echo get_theme_mod('googleplus_url','https://plus.google.com'); ?>" target="_blank"><i class="fab fa-google-plus-g fa-2x"></i></a>
        </li>
      </ul>
    </nav>
  </section><?php /** End Section **/ ?>
</header><?php /** End Header **/ ?>