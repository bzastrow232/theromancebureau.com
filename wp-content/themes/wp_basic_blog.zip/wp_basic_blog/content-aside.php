<div class = "card-posts post-aside">
	<div class = "well" style = "background: #8f9193;">
		<small><?php the_author(); ?>@<?php the_date(); ?></small>
		<?php the_content(); ?>
	</div>
</div>